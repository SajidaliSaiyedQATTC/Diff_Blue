package com.diffblue.interview;



public class Question_4 {
	
	// 1. We can validate the following set of conditions :
	
	//1.1=> Validate  the file format  
	/*Check the file types=> for example .java .text
	 * 
	 * private static void validateFileFormat(final String errorMessage) {
    System.out.println(errorMessage);
    System.exit(1);
  }
	
	
	let filetypeCollection=[".java",".txt"]
	if(fileName.constains(filetypeCollection)){
	
	}
	else
	{
	//if user give .exe or .png then throw error 
	 * validateFileFormat("file format is not supported")
	 * 
	}
	
	*/
	
	
	//2. Validate different types of exception 
	
	/* If code class empty, I mean if file is not assigned then we can handle different exception
	 * For example 
	 *  try {
      final File file = new File(filePath);
      codeClass = new ExampleClass(null);// Set the nulls by mistake 
    } catch (IOException e) {
      exitWithErrorMessage("The file does not exist");
    }
    catch (NullPointerException e) {
    	  exitWithErrorMessage("file object is not intialized");
	}
	 */
	
	
	
	//3.  Validate the total number of lines covered
	/* codeClass = new ExampleClass("FilePATH");
	 int totalLineCovered=codeClass.getLinesOfCode().size();
	 
	 
	//Return total number of lines of program
	public static long countLineFast(String fileName) {

	      long lines = 0;

	      try (InputStream is = new BufferedInputStream(new FileInputStream(fileName))) {
	          byte[] c = new byte[1024];
	          int count = 0;
	          int readChars = 0;
	          boolean endsWithoutNewLine = false;
	          while ((readChars = is.read(c)) != -1) {
	              for (int i = 0; i < readChars; ++i) {
	                  if (c[i] == '\n')
	                      ++count;
	              }
	              endsWithoutNewLine = (c[readChars - 1] != '\n');
	          }
	          if (endsWithoutNewLine) {
	              ++count;
	          }
	          lines = count;
	      } catch (IOException e) {
	          e.printStackTrace();
	      }

	      return lines;
	  }
	
	long actualCOveredLines=testing.countLineFast("/Users/sajidalisaiyed/Downloads/QA-Test/src/main/java/com/diffblue/interview/testing.java");
	
	assertEquals(actualCOveredLines,totalLineCovered);
	
	
		*/
	
	

	//4. Random Test line of code and Actual test number should be not same
	
	/* 4.1=>
	 * final ExampleTest codeTest = new ExampleTest("Random Test");
	 * int randomTestLineOCode=codeTest.getCoveredLines().size();
	 * assertEquals(actualCOveredLines,randomTestLineOCode)
	 *
	 * */
	

	
	//5. we can remove the  blank line and get the actual line of codes
	
	
	/*=> In exampleClass.java
	 * 
	 * if we add one more condition in readAllLines() method
	while (line != null ||  line !="") { //added new condition  line !=""
	       
        lines.add(line);
        line = bufferedReader.readLine();
    }
	 */
	
	

}

package com.diffblue.interview;


import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class Question3 {
	
	
	
	//Read java file and return total number of line of program 
	
	public static long readFullLineOfCode(String fileName) {
		
		   long lines = 0;
	      try (InputStream is = new BufferedInputStream(new FileInputStream(fileName))) {
	          byte[] c = new byte[1024];
	          int count = 0;
	          int readChars = 0;
	          boolean endsWithoutNewLine = false;
	          while ((readChars = is.read(c)) != -1) {
	              for (int i = 0; i < readChars; ++i) {
	                  if (c[i] == '\n')
	                      ++count;
	              }
	              endsWithoutNewLine = (c[readChars - 1] != '\n');
	          }
	          if (endsWithoutNewLine) {
	              ++count;
	          }
	          lines = count;
	      } catch (IOException e) {
	          e.printStackTrace();
	      }

	      return lines;
	      
	      
	}
	
			//validate the  consistent between  two(Actual test and random test) test
			/*
			 * First read codetest.java file and return total number of lines of that program
			 * Secondly, using random method get random number of line of codetest.java and then validate the randomly generated number-
			 * should be less than the actual codetest.java file 
			 */
		public static void validateTwoRandomTest() throws IOException {
		
			
			File filePath=new File("src/main/java/com/diffblue/interview/hello.txt");
			
			
			long firsTestWholeLine=Question3.readFullLineOfCode("src/main/java/com/diffblue/interview/CodeTest.java");
			long SecondTestWholeLine=Question3.readFullLineOfCode("src/main/java/com/diffblue/interview/ExampleTest.java");
			
		
			
			 final ExampleTest codeTest = new ExampleTest("Random Test");
			    CodeClass codeClass = null;
	
			    boolean statusOfFirstFile=false;
			    boolean statusOfSecondFile=false;
			    try {
			    final File file = new File("src/main/java/com/diffblue/interview/CodeTest.java");
			           codeClass = new ExampleClass(file);
			           int i=0;
			           if (codeClass != null) {
					  codeTest.testAgainst(codeClass);
					  i=codeTest.getCoveredLines().size();
					 
					}
			           if((i < firsTestWholeLine) ) {
					    	System.out.println("Random:1 "+i);	
					    	statusOfFirstFile=true;
					    	 assertTrue(statusOfFirstFile);
					    }
					    else
					    {
					    	fail("First ExampleTest.java  file is out range ");
					    }
					    
			    }
			    catch (Exception e) {
					fail(e);
				}
			    
			  try
			  {
			  
			    final File file2 = new File("src/main/java/com/diffblue/interview/CodeTest.java");
		           codeClass = new ExampleClass(file2);
		           int i2=0;
		    if (codeClass != null) {    	
		      codeTest.testAgainst(codeClass);	    
		      i2=codeTest.getCoveredLines().size();
		     
		    }
		    
		    if(( i2 < SecondTestWholeLine) ) {
		    	statusOfSecondFile=true;
		    	  assertTrue(statusOfSecondFile);
		    	System.out.println("Random:2 "+i2);
		    }
		    else
		    {
		    	fail("second CodeTest.java  file is out range ");
		    }
		   
			  }
			  catch (Exception e) {
				fail(e);
			}
		}
		
		
		public static void main(String[] args) throws IOException {
			Question3.validateTwoRandomTest();
		}

}

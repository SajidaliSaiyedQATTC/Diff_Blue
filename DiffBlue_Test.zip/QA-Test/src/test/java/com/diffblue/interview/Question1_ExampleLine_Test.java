package com.diffblue.interview;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.lang.reflect.Method;
import java.util.ArrayList;

public class Question1_ExampleLine_Test  extends ExampleLine{


    private final int lineNumber;
    private String contents;

    Question1_ExampleLine_Test(int lineNumber, String contents) {
		super(lineNumber, contents);
		this.lineNumber=lineNumber;
		this.contents=contents;
	
		
	}
	
		
				//validate  total line number and its contents 
				void validateContents (int lineNumber,String Data) {						
					Question1_ExampleLine_Test Obj=new Question1_ExampleLine_Test(this.lineNumber, this.contents);
					int   NumberOfLines=Obj.getLineNumber();
					
					//Validate Line Number
					assertEquals(lineNumber,NumberOfLines);		
					
					//validate contents
					assertEquals(Data, Obj.getContents());
				
					
				
					
				}
				
				//Validate the null values of getLineNumber() & getContents()
				void ValidateNegativeData() {
					
					Question1_ExampleLine_Test Obj=new Question1_ExampleLine_Test(this.lineNumber, this.contents);
					
				
					assertNotNull(Obj.getLineNumber());
					
					assertNotNull(Obj.getContents());
					
					
				}
				
				 
				//Validate  data type of  getLineNumbe() & getContents()
				void validateDataType(String DataType1, String DataType2) {
					Question1_ExampleLine_Test Obj=new Question1_ExampleLine_Test(this.lineNumber, this.contents);
					assertEquals(DataType1, ((Object)Obj.getLineNumber()).getClass().getSimpleName());
					
					assertEquals(DataType2,((Object)Obj.getContents()).getClass().getSimpleName() );
					
							
				}
				
	
				
				//Validate class and Implementations
				/*validteImplementions()==> it retrieves CodeLine's class interface and  Example class implemented Methods  
				 * Then method check the ExampleLine class has implemented  all interface  methods of CodeLine class 
				 */
				void validteImplementions() throws NoSuchMethodException, SecurityException {
					ExampleLine Obj=new ExampleLine(this.lineNumber, this.contents);
					
					Method[] mthd=Obj.getClass().getInterfaces()[0].getDeclaredMethods();
					Method[] mthd2=Obj.getClass().getDeclaredMethods();
					
					ArrayList<String> list_of_interfaces = new ArrayList<>();
					ArrayList<String> list_of_implemented_methods = new ArrayList<>();
					
					
					  for(int i = 0; i < mthd.length; i++) {  
				          
				            list_of_interfaces.add(mthd[i].getName());
				         }  
				      
					  for(int i = 0; i < mthd2.length; i++) {  
						  list_of_implemented_methods.add(mthd2[i].getName());
						  
				         }
					  boolean boolval = list_of_interfaces.equals(list_of_implemented_methods);
					 
					  assertEquals(boolval, true);
					
					
				}
				
				

				public static void main(String[] args) throws NoSuchMethodException, SecurityException {
			
					Question1_ExampleLine_Test ex=new Question1_ExampleLine_Test(1, "sajid");
					//validate  contents and total line number
					ex.validateContents(1,"sajid");
					
					//Validate the negative data
					ex.ValidateNegativeData();
					
					//Validate different data types
					ex.validateDataType("Integer","String");
					
					//Validate class and Implementations
					ex.validteImplementions();
					
					
					 
				}
}

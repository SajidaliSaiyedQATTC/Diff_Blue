package com.diffblue.interview;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class Question2_Example_Class {
	
	ExampleClass obj;
	public Question2_Example_Class(File filePath) throws IOException {
		obj=new ExampleClass(filePath);
		
	}

	//Filter out Query or  any HamrfulWord
	//And  emjoi==>String emo_regex = "([\\u20a0-\\u32ff\\ud83c\\udc00-\\ud83d\\udeff\\udbb9\\udce5-\\udbb9\\udcee])";
	// Also  Special Char
	void ValidateHamrfulWordAndSpeicalChar(String Data) {
		boolean checkQueryPresent;
		List<CodeLine>list =this.obj.getLinesOfCode();
		for(int i=0;i<list.size();i++) {
		if(list.get(i).getContents().contains(Data)) {
			
			String dbQuery=list.get(i).getContents().toString();
			
			checkQueryPresent=true;
			System.out.println("found"+dbQuery);
			//now found database Query 
			/*
			 * So  we can remove it
			 *if(checkQueryPresent==true)
			 *{
			 *list.remove(i);
			 *}
			 */
		}
		
		}
	}
	
	
	//Validate File contents and its line number 
	void validateFileContents(String data,int lineNumber) {
		
		int checktextPresent = 0;
	
		List<CodeLine>list =this.obj.getLinesOfCode();
		for(int i=0;i<list.size();i++) {
			
			System.out.println(list.get(i).getContents());
			
			
			if(list.get(i).getContents().contains(data)) {
				
					checktextPresent=i;
					checktextPresent++;
			}
	
			assertEquals(checktextPresent,lineNumber);
	
			
			
		}
		
	}
	
	public static void main(String[] args)throws IOException {
		
				File filePath=new File("src/test/java/com/diffblue/interview/hello.txt");
				 String emjoiList = "([\\u20a0-\\u32ff\\ud83c\\udc00-\\ud83d\\udeff\\udbb9\\udce5-\\udbb9\\udcee])";
				String DatabBaseQuery="Select *";
				Question2_Example_Class obj=new Question2_Example_Class(filePath);
				
				//Validate File contents and its line number 
				obj.validateFileContents("hello good morning",1);
				
				//Filter out database Query
				obj.ValidateHamrfulWordAndSpeicalChar(DatabBaseQuery);
				
				//Filter out different emojis
				obj.ValidateHamrfulWordAndSpeicalChar(emjoiList);
				
				
				
				
					
				
	}

}

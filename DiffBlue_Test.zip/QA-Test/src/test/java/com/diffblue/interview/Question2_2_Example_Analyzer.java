package com.diffblue.interview;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Set;

public class Question2_2_Example_Analyzer {
	
	
	
	//Validate testName, supported emthods and total number of lines of program 
	public static void TestExampleAnalyzer() throws IOException {
		CodeTest t=null;
		ExampleAnalyzer c2=new ExampleAnalyzer();
	
	    CodeClass codeClass = null;
	    //codeClass = (CodeClass) new ExampleTest("/Users/sajidalisaiyed/Downloads/QA-Test/src/main/java/com/diffblue/interview/CodeTest.java");
	    CodeTest codeTest=null;
	   
	    
	    final File file = new File("src/main/java/com/diffblue/interview/CodeTest.java");
	      
	      codeClass = new ExampleClass(file);
	   // 
	      codeTest = new ExampleTest("src/main/java/com/diffblue/interview/CodeTest.java");
	     int numberOFlines=0;

	       final CodeAnalyzer codeAnalyzer = new ExampleAnalyzer();
	      final Set<CodeLine> coveredLines = codeAnalyzer.runTest(codeTest);
	     
	          
	      // Print out all lines, denoting covered lines prefixed with an X
	      for (final CodeLine line : codeClass.getLinesOfCode()) {
	    	  numberOFlines++;
	        String printedLine = "";
	        if (coveredLines.contains(line)) {
	          printedLine = "X";
	        } else {
	          printedLine = " ";
	        } 
	        printedLine += String.format(
	                " %03d %s ",
	                line.getLineNumber(),
	                line.getContents()
	         
	     
	     ); 
	                System.out.println(printedLine);
	     
	      }
	      
	   assertEquals(22, numberOFlines);
	   //System.out.print(codeTest.getName());
	  assertEquals(codeTest.getName(), "src/main/java/com/diffblue/interview/CodeTest.java");
	      
	      
			
		}

		
	public static void main(String[] args) throws IOException {
		
			Question2_2_Example_Analyzer.TestExampleAnalyzer();
		
		
	}

}
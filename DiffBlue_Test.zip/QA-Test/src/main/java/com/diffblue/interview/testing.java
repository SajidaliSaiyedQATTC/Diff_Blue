package com.diffblue.interview;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class testing 
{

	
	public static long countLineFast(String fileName) {
	      long lines = 0;
	  
	      try (InputStream is = new BufferedInputStream(new FileInputStream(fileName))) {
	          byte[] c = new byte[1024];
	          int count = 0;
	          int readChars = 0;
	          boolean endsWithoutNewLine = false;
	          while ((readChars = is.read(c)) != -1) {
	              for (int i = 0; i < readChars; ++i) {
	                  if (c[i] == '\n')
	                      ++count;
	              }
	              endsWithoutNewLine = (c[readChars - 1] != '\n');
	          }
	          if (endsWithoutNewLine) {
	              ++count;
	          }
	          lines = count;
	      } catch (IOException e) {
	          e.printStackTrace();
	      }

	      return lines;
	  }

	
	
	public static void main(String[] args) throws IOException  {
		
		
		CodeAnalyzer c=new CodeAnalyzer() {
			
			@Override
			public Set<CodeTest> uniqueTests() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public Set<CodeLine> runTestSuite(Set<CodeTest> tests) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public Set<CodeLine> runTest(CodeTest test) {
				// TODO Auto-generated method stub
				return null;
			}
		};
		CodeTest t=null;
		ExampleAnalyzer c2=new ExampleAnalyzer();
	 
	   
	    CodeClass codeClass = null;
	    //codeClass = (CodeClass) new ExampleTest("/Users/sajidalisaiyed/Downloads/QA-Test/src/main/java/com/diffblue/interview/CodeTest.java");
	    CodeTest codeTest=null;
	   
	    
	    final File file = new File("/Users/sajidalisaiyed/Downloads/QA-Test/src/main/java/com/diffblue/interview/CodeTest.java");
	      
	      codeClass = new ExampleClass(file);
	   // final File file = new File("/Users/sajidalisaiyed/Downloads/QA-Test/src/main/java/com/diffblue/interview/CodeTest.java");
	      
	      codeTest = new ExampleTest("/Users/sajidalisaiyed/Downloads/QA-Test/src/main/java/com/diffblue/interview/CodeTest.java");
	     
	      
	     
	     
	     // codeClass.getFile();
	      
	  
	       final CodeAnalyzer codeAnalyzer = new ExampleAnalyzer();
	      final Set<CodeLine> coveredLines = codeAnalyzer.runTest(codeTest);
	     
	            
	
	      // Print out all lines, denoting covered lines prefixed with an X
	      for (final CodeLine line : codeClass.getLinesOfCode()) {
	    	
	        String printedLine = "";
	        if (coveredLines.contains(line)) {
	          printedLine = "X";
	        } else {
	          printedLine = " ";
	        }
	        printedLine += String.format(
	                " %03d %s ",
	                line.getLineNumber(),
	                line.getContents()
	          
	     
	     ); 
	                System.out.println(printedLine);
	     
	      }
	      
	    
	    
			
		}
		
		
	
		
		
	
	
}

Question 1 Consider the class Example Line. Which parts of this class would you test and which would you not test? Why?
Class =Question1_ExampleLine_Test.java
Answer=> I have covered following set of conditions 
		1.1 validate  total line number and its contents 
		2.2 Validate the null values of getLineNumber() & getContents()
		2.3 Validate  data type of  getLineNumbe() & getContents()
		2.4 Validate class and Implementations
		
		

		
Question 2 Write tests for the classes ExampleClass and ExampleAnalyzer.

For methods that you choose to test, write down which sets of inputs you have chosen to test and explain why you have chosen those inputs. Keep also in mind that in order to test ExampleAnalyzer, you will likely have to interact with ExampleTest, which has a random component. Make sure that your unit tests pass reliably in repeated executions.

Answer=>
First part :
For methods that you choose to test, write down which sets of inputs you have chosen to test and explain why you have chosen those inputs.
Class: Question2_Example_class.java
	I have covered following set of conditions 
		//Validate File contents and its line number 
		//Filter out Query or  any HamrfulWord
		//Filter out emjoi==>String emo_regex = "([\\u20a0-\\u32ff\\ud83c\\udc00-\\ud83d\\udeff\\udbb9\\udce5-\\udbb9\\udcee])";
		/ Also  Special Char
		

Second Part:
Class: Question2_2_Example_Analyzer.java
I have covered following set of conditions 
	//Validate test names
	//Supported methods
	//Total line of programs
	
	
	


Question 3:
Consider the use case where the program is used to find all lines of code covered in a Java source file by at least two different test files. Write an end-to-end test for this use case.

Answer:=>
Class: Question3.java

=>				//validate the  consistent between  two(Actual test and random test) test
			/*
			 * First read codetest.java file and return total number of lines of that program
			 * Secondly, using random method get random number of line of codetest.java and then validate the randomly generated number-
			 * should be less than the actual codetest.java file 
			 */
	
	
Question 4::Briefly describe how you would perform a manual test of the main application included in this example (ExampleApplication#main). What inputs to the application would you consider and what behaviour might you be looking for?


Answer:=> 
Class: Question4.java
		
I have covered following set of conditions 
4.1  Validate  the file format 
4.2 	Validate different types of exception 
4.3 Validate the total number of lines covered
4.4  Random Test line of code and Actual test number should be not same
4.5 we can remove blank line and get the actual line of codes


	
	
			

